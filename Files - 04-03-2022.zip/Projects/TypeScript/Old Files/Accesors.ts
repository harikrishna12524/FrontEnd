class User{

    private _name:string;
    private _city:string;

    constructor(name:string, city:string){
        this.name = name;
        this.city = city;
    }

    public set name(name:string){
        if(name.length > 3){
            this._name = name;
        }else{
            console.log("Name Cannot Be Lesser then three letters");
            console.log("Come on serious ???");
        }
    }

    public get name():string{
        return this._name;
    }

    public set city(city:string){
        this._city = city;
    }

    public get city():string{
        return this._city;
    }
}

var user = new User("Harikrisha", "Coimbatore");
user.name = "";
console.log(user.name);