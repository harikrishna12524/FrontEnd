let b = [5,1,4,8,6,9,3,5,6,4];

for(let i = 0; i < 10; i++){
    console.log(b);
}