class User{
    protected usrname:string;
    private _password:number;

    constructor(usrname:string, password:number){
        this.usrname = usrname;
        this.password = password;
    }

    public validate(usrname:string, password:number):boolean{
        if(this.usrname == usrname && this.password == password){
            return true;
        }
        return false;
    }

    protected set password(password:number){
        this._password = password;
    }

    // protected get password():number{
    //     return this._password;
    // }
}

class Buyer extends User{
    private amount:number = 5000;

    // constructor(usrname:string, password:number,amount:number){
    //     super(usrname, password);
    //     this.amount = amount;
    // }

    public intro():void{
        console.log(this.usrname + " Has " + this.amount);
    }

    
    public validate(name:string, password:number, amount:number):boolean{
        return super.validate(name, password);
    }
}

var per1 = new Buyer("hari", 1234);
per1.validate("",0);