class Product{
    sell(){
        let sold = 1;
        console.log("product Sold");
    }
}

let product = new Product;
product.sell();