class Greet{
    static genGreet:string = "Hello, World!";

    static greet():void{
        console.log(Greet.genGreet);
    }

    greeting:string;

    constructor(name:string){
        this.greeting = "Hello, " + name;
    }

    public greet():void{
        console.log(this.greeting);
    }
}

// Static Welcome
Greet.greet();

// Non static Greeting
var greet = new Greet("Harikrishna");
greet.greet();