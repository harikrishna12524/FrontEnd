class User{
    private usrname:string;
    private password:number;

    private static usrname:string;
    private static password:number;

    constructor(usrname:string, password:number){
        this.usrname = usrname;
        this.password = password;
    }

    public static validate(usrname:string, password:number):boolean{
        if(this.usrname == usrname && this.password == password){
            return true;
        }
        return false;
    }
}

let user1 = new User("hari",1234);
console.log(User.validate.call(user1, "hari", 1234));