// var a:number[] = [12,45,2,6,3,4,78,5,2,1];

// for(let i of a){
//     if(i%2==0){
//         console.log("Even Number");
//     }else{
//         console.log("Odd Number");
//     }
// }

/*
var a = 10;
do{
    console.log("Incrementing");
    a++;
}while(a < 10);

console.log("Number is now : " + a);
*/

// var d =(function a (a){

// return (()=>{
    
// //    this.a=10;
//     console.log(a);
//     return "7";
//         })()
    
//     })(8);
//     console.log(d);
    
class ArrayList{
    private nums:number[];
    public lenght:number;

    constructor(len?:number){
        for(let a = 0; a < len; a++){
            this.nums[a] = 0;
        }
        length = 0;
    }

    public add(num:number){
        this.nums.push(num);
        length++;
    }
}

var arraylist = new ArrayList();
arraylist.add(5);