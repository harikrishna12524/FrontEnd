var a:number = 9;

class student{
    studentName:string;
    studentId:string;

    constructor(name, id){
        this.studentName = name;
        this.studentId = id;
    }

    public introduce(){
        console.log("My name is " + this.studentName);
    }
}

var increment = (function(){
    console.log(this);
    let a = 0;
     return ()=>{
         console.log(a++);
        };
    })();

increment();
increment();
increment();
increment();