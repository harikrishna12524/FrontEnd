class Main{
    public static main(args:string[]):void{
        let num:number = 5;
        let nums:number[] = [4,7,2,8,6];

        let sum:number = 0;
        for(let i = 0; i < num; i++){
            sum+=nums[i];
        }
        console.log(sum);
    }
}

Main.main([]);