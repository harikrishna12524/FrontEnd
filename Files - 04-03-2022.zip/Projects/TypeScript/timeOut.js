var effect = {
    intervals: [],
    setup: function (call1, call2) {
        this.intervals.push(setInterval(call1, 250));
        this.intervals.push(setInterval(call2, 350));
    },
    stop: function () {
        for (var i = this.intervals.length - 1; i >= 0; i++) {
            clearInterval(this.intervals.pop());
        }
    },
    start: function (call1, call2) {
        for (var i = 1; i < 5; i++) {
            setTimeout(this.setup, 1532 * i, call1, call2);
        }
    }
};
var body = document.getElementById("body");
var smallArea = document.getElementById("title");
function lightining() {
    body.style["background-color"] = "black";
    smallArea.style.color = "White";
    smallArea.innerHTML = "Voldamort is comming !";
}
function offTitle() {
    body.style["background-color"] = "white";
    smallArea.style.color = "black";
    smallArea.innerHTML = "HARRY POTTER";
}
function fire() {
    effect.start(lightining, offTitle);
}
