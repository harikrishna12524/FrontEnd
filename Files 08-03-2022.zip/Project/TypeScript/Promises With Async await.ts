async function increm(add){
    return new Promise((resolve)=>{
      setTimeout(resolve, Math.random()*500, add+1);
    })
  }
  
async function getNums(name,num){
  for(var a = num; a < num+5; a++){
    await increm(a).then((res)=>{
      console.log(` ${name} has ${res}`);
    });
  }
}
  

async function overall(){  
  await getNums("Func1", 5);
  await getNums("Func2", 25);
}