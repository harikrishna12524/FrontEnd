var proms = [];
function wantPromise() {
    return new Promise(function (res, rej) {
        console.log("I am called");
        res("I don't know why.");
        return "I am something";
    });
}
var curProm = wantPromise();
console.log(Promise.resolve(curProm));