var proms = [];

function wantPromise(){
    return new Promise((res, rej)=>{
        console.log("I am called");
        res("I don't know why.");
        return "I am something";
    });
}

var curProm = wantPromise();

var another = Promise.resolve(curProm);

console.log(another);